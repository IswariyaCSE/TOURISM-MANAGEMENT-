package dbmsOopsProject;

import java.sql.*;
import java.util.HashMap;
import java.util.Scanner;

import dbmsOopsProject.username.secure;

public class Admin extends secure {
    private HashMap<String, String> str = new HashMap<String, String>();
    private Connection con;
    private Statement smt;
    private ResultSet rs;

    Admin() {
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost/login", "root", "Sece@2021");
            smt = con.createStatement();
            rs = smt.executeQuery("select * from login");
            while (rs.next()) {
                str.put(rs.getString("Username"), rs.getString("Password"));
            }

        } catch (SQLException e) {
            System.out.println("Error getConnection pls try again");
            System.out.println("Restart initization connection");

        }

    }

    public void deleteUser() throws Exception {
        System.out.println("Username");
        System.out.println("-----------------------------------------");
        ;
        for (String s : str.keySet()) {
            System.out.println(s);
        }
        String user;
        System.out.println("Enter the user name");
        Scanner sc = new Scanner(System.in);
        user = sc.next();
        PreparedStatement stmt = con.prepareStatement("delete from login where Username = ?");
        stmt.setString(1, user);
        int m = stmt.executeUpdate();
        if (m > 0) {
            System.out.println("Username is successfully deleted");
            str.remove(user);
            s.remove(user);
        }
    }
}
