package dbmsOopsProject;

import java.io.Console;
import java.util.Scanner;
import dbmsOopsProject.username.secure;

public class login extends secure {

    public login() {

    }

    public boolean checkUser(String user, String password) {
        if (s.containsKey(user)) {
            if (s.get(user).compareTo(password) == 0) {
                return true;

            }
            return false;
        }
        return false;
    }

    public boolean verifyUser() throws Exception {
        String user, password;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the choice\n1)Existing USer\n2)New User");
        int ch = sc.nextInt();
        Console con = System.console();
        if (ch == 1) {
            // sc.next();
            System.out.println("Enter the user name");
            user = sc.next().trim();
            System.out.println("Enter your password");
            char[] pass = con.readPassword();
            password = new String(pass);
            try {
                login l = new login();
                if (l.checkUser(user, password) == false) {
                    throw new Exception();
                } else {
                    System.out.println("!!!!!!!!!!!  Welcome Sir  !!!!!!!!!!");
                    return true;
                }
            } catch (Exception e) {
                System.out.println("Invalid User");
                return false;
            }
        } else {
            login l = new login();
            l.insertUser();
            System.out.println("Enter the user name");
            user = sc.next().trim();
            System.out.println("Enter your password");
            char[] pass = con.readPassword();
            password = new String(pass);
            System.out.println("Entered password is " + password);
            try {
                l = new login();
                if (l.checkUser(user, password) == false) {
                    throw new Exception();
                } else {
                    System.out.println("!!!!!!!!!!!  Welcome Sir  !!!!!!!!!!");
                    return true;
                }
            } catch (Exception e) {
                System.out.println("Invalid User");
                return false;
            }
        }
    }

    public void insertUser() throws Exception {
        Scanner sc = new Scanner(System.in);
        Console con = System.console();
        System.out.println("Enter the user");
        String name = sc.next();
        while (s.containsKey(name) == true) {
            System.out.println("Oops! User Already Exist!! Try Different Name");
            name = sc.next();
        }
        char[] pass = con.readPassword();
        String password = new String(pass);
        System.out.println("Entered password is " + password);
        this.insert(name, password);
    }
}
