package dbmsOopsProject;

import java.sql.*;

class mySqlconnection {
    public static Connection getConnection() {
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/college", "root", "Sece@2021");
            return con;
        } catch (SQLException e) {
            System.out.println("Error getConnection pls try again");
            System.out.println("Restart initization connection");
            return getConnection();
        }
    }
}
