package dbmsOopsProject;

import java.sql.Connection;
import java.util.*;

public class App {

    public static void main(String[] args) throws Exception {
        login l = new login();
        Scanner sc = new Scanner(System.in);
        System.out.println("1)Admin\n2)User");
        int ch = sc.nextInt();
        if (ch == 1) {
            Admin m = new Admin();
            char chioce;
            System.out.println("Do you want to delete a user (y/n): ");
            String s = sc.next();
            chioce = s.charAt(0);
            if (chioce == 'y') {
                m.deleteUser();
            }
            return;
        } else {
            if (l.verifyUser() == false) {
                return;
            }
            Connection con = mySqlconnection.getConnection();
            int placeid = BussinessOperation.getPlace(con);
            int n;
            // n = sc.nextInt();
            do {
                // n = sc.nextInt();
                System.out.println(
                        "1)Spots in location\n2)Travel agency\n3)Hotel around location\n4)Public Transport\n5)Change the place\n6)Exit");
                // sc.next();
                n = sc.nextInt();

                switch (n) {
                    case 1:
                        BussinessOperation.getSpots(con, placeid);
                        break;
                    case 2:
                        BussinessOperation.getTravelAgency(con, placeid);
                        break;
                    case 3:
                        BussinessOperation.getHotel(con, placeid);
                        break;
                    case 4:
                        BussinessOperation.getpublicTransport(con, placeid);
                        break;
                    case 5:
                        placeid = BussinessOperation.getPlace(con);
                        break;
                    case 6:
                        System.out.println("Thank you !!! visit again.");
                        break;

                }
                Thread.sleep(5000);
            } while (n != 6);
        }

    }
}
