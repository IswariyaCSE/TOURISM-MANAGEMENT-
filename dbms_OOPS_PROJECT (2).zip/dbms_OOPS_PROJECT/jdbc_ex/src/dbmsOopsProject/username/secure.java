package dbmsOopsProject.username;

import java.sql.*;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;

public class secure {
    protected static HashMap<String, String> s = new HashMap<String, String>();
    private Connection con;
    private Statement smt;
    private ResultSet rs;

    public secure() {

        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost/login", "root", "Sece@2021");
            smt = con.createStatement();
            rs = smt.executeQuery("select * from login");
            while (rs.next()) {
                s.put(rs.getString("Username"), rs.getString("Password"));
            }

        } catch (SQLException e) {
            System.out.println("Error getConnection pls try again");
            System.out.println("Restart initization connection");
            ;
        }
    }

    public void insert(String user, String password) throws SQLException {

        PreparedStatement stmt = con.prepareStatement("insert into login values(?,?)");
        stmt.setString(1, user);
        stmt.setString(2, password);
        int m = stmt.executeUpdate();
        if (m > 0) {
            System.out.println("Successfully UserId Created");
            s.put(user, password);
        }

    }
}
