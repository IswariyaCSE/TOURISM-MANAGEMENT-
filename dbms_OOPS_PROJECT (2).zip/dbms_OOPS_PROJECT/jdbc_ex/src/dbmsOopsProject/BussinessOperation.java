package dbmsOopsProject;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.*;

public class BussinessOperation {
    /**
     * @param con
     * @return
     * @throws Exception
     */
    public static int getPlace(Connection con) throws Exception {
        Statement smt = con.createStatement();
        ResultSet rs = smt.executeQuery("select * from place");
        List<place> s = new ArrayList<place>();
        while (rs.next()) {
            place p = new place();
            p.setName(rs.getString("Name"));
            p.setRating(rs.getDouble("Rating"));
            p.setPlaceid(rs.getInt("Placeid"));
            s.add(p);
        }
        System.out.println("Placeid " + "Name " + "Rating ");
        for (place p : s) {
            System.out.println(p.getPlaceid() + " " + p.getName() + " " + " " + p.getRating());
        }
        int id;
        System.out.println("Enter the place id");
        Scanner sc = new Scanner(System.in);
        id = sc.nextInt();

        return id;
    }

    /**
     * @param con
     * @param placeid
     * @throws SQLException
     */
    public static void getSpots(Connection con, int placeid) throws SQLException {
        Statement smt = con.createStatement();
        ResultSet rs = smt.executeQuery("select * from spots where Placeid = " + placeid);
        ArrayList<spot> s = new ArrayList<spot>();
        while (rs.next()) {
            spot spots = new spot();
            spots.setName(rs.getString("Name"));
            spots.setSeasonToVisit(rs.getString("seasonToVisit"));
            spots.setPlaceid(rs.getInt("Placeid"));
            spots.setSpotid(rs.getInt("Spotid"));
            spots.setPeoplePerYear(rs.getLong("peoplePerYear"));
            s.add(spots);
        }
        System.out.println("Spotid " + "Placeid " + "Name " + "PeoplePerYear " + "SeasonToVisit ");
        for (spot sp : s) {
            System.out.println(sp.getSpotid() + " " + sp.getPlaceid() + " " + sp.getName() + " " + sp.getPeoplePerYear()
                    + " " + sp.getSeasonToVisit());
        }
    }

    public static void getTravelAgency(Connection con, int placeid) throws SQLException {
        Statement smt = con.createStatement();
        ResultSet rs = smt.executeQuery("select * from travel_agency");
        ArrayList<travelAgency> arr = new ArrayList<travelAgency>();
        while (rs.next()) {
            travelAgency tr = new travelAgency();
            tr.setAmount(rs.getDouble("amount"));
            tr.setContact(rs.getString("contact"));
            tr.setPackageDetails(rs.getString("packages"));
            tr.setName(rs.getString("name"));
            arr.add(tr);
        }
        System.out.println("Name   contact    packages    amount");
        for (travelAgency tr : arr) {
            System.out.println(
                    tr.getName() + " " + tr.getContact() + " " + tr.getPackageDetails() + " " + tr.getAmount());
        }
    }

    /**
     * @param con
     * @param placeId
     * @throws SQLException
     */
    public static void getpublicTransport(Connection con, int placeId) throws SQLException {
        Statement smt = con.createStatement();
        ResultSet rs = smt.executeQuery("select * from public_transports where end=" + placeId);
        ArrayList<publicTransport> arr = new ArrayList<publicTransport>();
        while (rs.next()) {
            publicTransport p = new publicTransport();
            p.setFrom(rs.getString("start"));
            p.setTo(placeId);
            p.setName(rs.getString("name"));
            p.setMode(rs.getString("mode"));
            p.setPrice(rs.getDouble("price"));
            arr.add(p);
        }
        System.out.println("Start    Name    Mode    Price");
        for (publicTransport p : arr) {
            System.out.println(p.getFrom() + " " + p.getName() + " " + p.getMode() + " " + p.getPrice());
        }
    }

    static int getValue() {
        Scanner sc = new Scanner(System.in);
        return sc.nextInt();
    }

    public static void getHotel(Connection con, int placeId) throws SQLException {
        Statement smt = con.createStatement();
        ResultSet rs = smt.executeQuery("select * from hotel where placeid=" + placeId);
        ArrayList<hotel> tmp = new ArrayList<hotel>();
        while (rs.next()) {
            hotel h = new hotel();
            h.setName(rs.getString("name"));
            h.setPlace(rs.getString("place"));
            h.setPlaceid(placeId);
            h.setAvailable(rs.getInt("available"));
            h.setRating(rs.getDouble("rating"));
            h.setRent(rs.getInt("rent"));
            tmp.add(h);
            System.out.println(h.getName() + " " + h.getPlace() + " " + h.getRating() + " " + h.getAvailable() + " "
                    + h.getRent());

        }
        System.out.println("Name Place Rating Avaliable Rent");
        for (hotel h : tmp) {
            System.out.println(h.getName() + " " + h.getPlace() + " " + h.getRating() + " " + h.getAvailable() + " "
                    + h.getRent());
        }
    }
}
